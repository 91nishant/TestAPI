package com.niansoft.testapi.utils;

public class Constants {

}
